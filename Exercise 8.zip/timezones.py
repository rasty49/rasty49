# timezones.py

from datetime import datetime, timedelta

class TimeZone:
    def __init__(self, hours_offset):
        self._offset = timedelta(hours=hours_offset)

    @property
    def offset(self):
        return self._offset

    def tz_datetime(self, dt):
        return dt + self._offset

    def tz_now(self):
        utc_now = datetime.utcnow()
        return self.tz_datetime(utc_now)

if __name__ == "__main__":
    augustday = datetime(2017, 8, 17, 12)
    februaryday = datetime(2022, 2, 16, 9)

    Germany = TimeZone(1)
    print(Germany.tz_datetime(augustday))
    print(Germany.tz_datetime(februaryday))
